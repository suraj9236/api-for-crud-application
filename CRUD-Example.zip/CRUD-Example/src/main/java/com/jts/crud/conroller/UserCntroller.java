package com.jts.crud.conroller;

import com.jts.crud.entity.User;
import com.jts.crud.service.userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api")
public class UserCntroller {
    @Autowired
    private userService userService;
    @PostMapping("/save")
    public User save(@RequestBody User user)
    {
      return   userService.saveUser(user);
    }
    @GetMapping("/findAll")
    public List<User> findAll(){
        return userService.findAll();
    }
    @GetMapping("/findByid")
    public User findById(@RequestParam int id){
        return userService.findById(id);
    }
    @PutMapping("/update")
    public User update(@RequestBody User user){
        return userService.updateUser(user);
    }
@DeleteMapping("/deleteById")
    public void delete(@RequestParam int id){
        userService.deleteUser(id);
}
}
